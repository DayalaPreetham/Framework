"""All the constants to be place here"""


class HomePageConstants:
    page_title = 'Google'
    google_search = 'Google Search'


class AttributeConstants:
    value = 'value'
