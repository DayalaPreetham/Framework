# Google automation test framework

Give the framework in path_base under configuration/windows.json

Run start_sequencer.py to execute the scripts.

Results will be stored under logs folder
