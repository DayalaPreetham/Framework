from library import AllLibraryMethods


class AnyPage(AllLibraryMethods):
    pass
