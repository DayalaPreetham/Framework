from .US1001 import US1001


class AllTestCases(US1001):
    """All testcases initialized here"""
