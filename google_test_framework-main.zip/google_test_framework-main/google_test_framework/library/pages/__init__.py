from .home_page import Homepage

class PageObjectMethod(Homepage):
    pass