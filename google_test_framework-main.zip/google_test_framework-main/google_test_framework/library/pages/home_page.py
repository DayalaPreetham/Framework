from time import sleep
from datetime import datetime
from library import AllLibraryMethods
from library.constants import HomePageConstants


class Homepage(AllLibraryMethods):
    pass