from .selenium_wrapper import SeleniumWrapper
from .SystemInterface import SystemTest


class RunSequence:
    print("Hello World")
