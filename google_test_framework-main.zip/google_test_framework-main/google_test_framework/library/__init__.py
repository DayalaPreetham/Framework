from .start_stop import StartStop
from google_test import SystemTest


class AllLibraryMethods(SystemTest, StartStop):
    pass